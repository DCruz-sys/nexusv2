"""WebSocket handlers (v2)."""

