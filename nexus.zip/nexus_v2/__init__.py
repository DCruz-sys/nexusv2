"""Nexus v2 package (local-first engagement + run graph platform)."""

