"""Tool execution + registry adapters (v2)."""

