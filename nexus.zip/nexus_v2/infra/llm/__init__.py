"""LLM provider adapters (v2)."""

