"""Browser automation adapters (v2)."""

