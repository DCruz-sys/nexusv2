"""Infrastructure adapters (v2)."""

