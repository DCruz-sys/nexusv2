"""Event broker/adapters (v2)."""

