"""SQLite repositories (v2)."""

