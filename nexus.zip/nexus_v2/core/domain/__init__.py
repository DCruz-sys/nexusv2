"""Domain models (v2)."""

