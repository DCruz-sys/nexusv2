"""Ports (interfaces) for v2."""

