"""Usecases (application services) for v2."""

