"""Core logic (domain + usecases + ports) for v2."""

