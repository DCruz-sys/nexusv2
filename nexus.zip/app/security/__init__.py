"""Security utilities for scope enforcement and policy gates."""
