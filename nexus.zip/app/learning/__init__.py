"""Continuous learning pipeline (crawl + extract + distill)."""
