"""Shared services for cross-route/runtime coordination."""
