"""System-level runtime checks and capability inventory."""

